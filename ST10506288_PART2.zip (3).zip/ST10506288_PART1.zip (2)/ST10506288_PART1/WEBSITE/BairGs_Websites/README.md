# BAIRGS CLOTHING BOUTIQUE — PART 2 POE

**Module:** WEDE5020 — Web Development  
**Student number:** ST10506288s
---

## 1. Project Overview

Bairgs Clothing Boutique is a multi-page clothing website created for a modern fashion brand. 

For Part 2 of this project, I took the basic HTML pages built in Part 1 and improved them using modern CSS. The website is now fully styled, clean, easy to read, and works smoothly on mobile phones, tablets, and desktop screens using Flexbox, CSS Grid, and media queries.

### Pages Included:
* **`index.html` (Home):** Has the hero welcome banner, brand introduction, and links to top clothing categories.
* **`products.html` (Products):** Shows product cards with images, prices, category filters, and hover buttons.
* **`about.html` (About Us):** Tells the brand story, values, and quality standards.
* **`contact.html` (Contact Us):** Includes a contact form, store details, and an order tracking status section.
* **`cart.html` (Cart & Checkout):** Shows a summary of items in the cart alongside a checkout form.

---

## 2. Folder Structure

```text
bairgs-boutique/
│
├── css/
│   └── style.css            # Main CSS stylesheet for all pages
├── images/
│   ├── banner.jpg           # Home page main banner
│   ├── women.jpg            # Women's coat product image
│   ├── men.jpg              # Men's shirt product image
│   ├── shoes.jpg            # Shoes product image
│   └── bag.jpg              # Handbag product image
├── evidence/                # Screenshots from device testing
│   ├── desktop-home.png
│   ├── tablet-products.png
│   └── mobile-cart.png
├── index.html               # Home page
├── products.html            # Products catalog
├── about.html               # About page
├── contact.html             # Contact and tracking page
├── cart.html                # Cart and checkout page
└── README.md                # Project documentation
## 3. Changes Made from Part 1 

Based on the feedback and requirements for Part 2, I made the following improvements:
Moved all CSS to an external stylesheet: Removed all inline styles and <style> blocks inside the HTML files. Everything is now styled through one file (css/style.css).
Removed wireframe placeholders: Deleted old wireframe text placeholders like MAIN BANNER and FOOTER to make the site look like a finished, live store.
Added the Viewport meta tag: Added <meta name="viewport" content="width=device-width, initial-scale=1.0"> to every HTML page so that media queries work properly on mobile devices.
Replaced fixed tables with CSS Grid and Flexbox: Replaced old HTML tables and fixed 950px layouts with flexible grids and flex containers that automatically adjust to different screen sizes.
Improved accessibility and form labels: Added alt text to every image and linked all form inputs with proper <label for=""> tags.


## 4. Changelog

Date	Version	Type	What was done
2026-08-15	v1.0.0	Initial	Set up the basic HTML structure, wireframes, and text content from Part 1.
2026-09-10	v1.1.0	Fixes	Removed internal style tags and created the css/style.css file.
2026-09-15	v2.0.0	Styling	Added a CSS reset (box-sizing: border-box), fonts, and CSS variables for colors.
2026-09-18	v2.1.0	Layout	Rebuilt product sections, categories, and forms using CSS Grid and Flexbox.
2026-09-20	v2.2.0	UI Polish	Added hover effects on buttons and cards, focus outlines on form fields, and shadows.
2026-09-22	v2.3.0	Responsive	Added @media queries for tablets (850px) and mobile phones (580px).
2026-09-23	v2.4.0	Testing	Tested layouts on Chrome, Firefox, and Edge using mobile and tablet simulators.
2026-09-24	v2.5.0	Final Polish	Finished documentation, organized screenshot evidence, and checked all links.


## 5. CSS Styling and Responsive Design

5.1. Base Setup and CSS Variables
Used box-sizing: border-box across all elements so padding does not cause layout overflow.
Set up root variables in CSS to keep colors, borders, and transitions consistent across all pages:
code
CSS
:root {
  --color-primary: #1a1a1a;
  --color-accent: #c5a880;
  --color-bg: #fdfdfd;
  --color-border: #eaeaea;
  --transition: 0.3s ease;
}
Replaced fixed pixel widths on main containers with max-width: 1000px; width: 100%; so pages scale down nicely on smaller screens.

5.2. Typography
Used clean serif headings (Bodoni MT, Didot, serif) paired with easy-to-read body text.
Used clamp() on main headings so titles scale smoothly without breaking lines awkwardly on smaller screens.

5.3. Layouts (Flexbox & Grid)
Navbar: Uses Flexbox (display: flex) with flex-wrap so navigation links wrap neatly if space runs out.
Product Grids: Built with CSS Grid (grid-template-columns: repeat(auto-fit, minmax(200px, 1fr))), which automatically shifts items into fewer columns as the screen shrinks.
Cart & Checkout: Uses a 2-column grid on desktop and stacks into 1 column on mobile.

5.4. Hover and Focus States
Hover: Product cards move slightly upward (transform: translateY(-4px)) and buttons change background color when hovered over.
Focus: Form fields and clickable buttons have visible outlines when navigated with a keyboard.
Active: Buttons scale down slightly (scale(0.98)) when clicked for tactile feedback.

5.5. Screen Breakpoints
Desktop (Larger than 850px): Full multi-column view with a side-by-side cart and checkout layout.
Tablet (581px to 850px): Product cards adjust into a 2-column grid, and the cart stacks above the checkout form.
Mobile (580px and below): Navigation links stack vertically, product cards display 1 per row, and form inputs expand to 100% width for easy tapping.


## 6. Device Testing & Evidence
Testing was carried out between 22 September 2026 and 24 September 2026 using Google Chrome, Microsoft Edge, and Mozilla Firefox Developer Tools across the following screen sizes:
Screen Size	Device Tested	Resolution	Test Result
Desktop	Laptop / Monitor	1920 × 1080	Multi-column grid works as expected, content stays centered, and hover animations trigger smoothly.
Tablet	iPad / Galaxy Tab	768 × 1024	Products shift to 2 columns, padding stays balanced, and inputs fit within screen boundaries.
Mobile	iPhone / Pixel	390 × 844	Menu stacks cleanly, product cards fit in 1 column, buttons are easy to tap, and there is no horizontal scrolling.
(All testing screenshots are saved in the evidence/ folder as proof of testing).


## 7. References (IIE Harvard Format)
Duckett, J., 2014. HTML and CSS: Design and Build Websites. 1st ed. Indianapolis: John Wiley & Sons, Inc.
MDN Web Docs, 2026. CSS Grid Layout Guide. Mozilla Developer Network. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Grid_Layout [Accessed 25 September 2026].
MDN Web Docs, 2026. Responsive Images with picture and srcset. Mozilla Developer Network. Available at: https://developer.mozilla.org/en-US/docs/Learn/HTML/Multimedia_and_embedding/Responsive_images [Accessed 25 September 2026].
MDN Web Docs, 2026. Using CSS custom properties (variables). Mozilla Developer Network. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/Using_CSS_custom_properties [Accessed 25 September 2026].
World Wide Web Consortium (W3C), 2026. Web Content Accessibility Guidelines (WCAG) 2.1. Available at: https://www.w3.org/WAI/standards-guidelines/wcag/ [Accessed 25 September 2026